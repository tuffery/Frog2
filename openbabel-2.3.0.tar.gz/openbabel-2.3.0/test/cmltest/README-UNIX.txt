Adapted from Peter MR's 2003-08-06 DOS/Windows tests
by Geoff Hutchison 2003-11-07

Run test.sh to drive the whole test suite.
Uses the roundtrip program in the program above to ensure the files
are identical. (For some definition of identical.)

tests for various CML input and output options:
1: CML1
2: CML2
a: use array format


