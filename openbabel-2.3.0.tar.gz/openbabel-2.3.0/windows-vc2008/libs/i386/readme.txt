xdr.lib and xdr-0.dll are the import library and shared build of bsd-xdr-1.0.0 available from http://code.google.com/p/bsd-xdr/. These were built from source by starting the MSVC2008 shell, starting bash (provided by Cygwin), and running the command "make -f Makefile.msvc80".

The include files in %ROOT%/windows-vc2008/include are also from this code base.
